// Navigation between sections
const navLinks = document.querySelectorAll('[data-nav-link]');
const pages = document.querySelectorAll('[data-page]');

navLinks.forEach(link => {
  link.addEventListener('click', () => {
    navLinks.forEach(btn => btn.classList.remove('active'));
    pages.forEach(page => page.classList.remove('active'));

    link.classList.add('active');
    const targetPage = link.textContent.toLowerCase();
    document.querySelector(`[data-page="${targetPage}"]`).classList.add('active');
  });
});

// Sidebar toggle (Show Contacts)
const sidebarBtn = document.querySelector('[data-sidebar-btn]');
const sidebarMore = document.querySelector('.sidebar-info-more');

if (sidebarBtn) {
  sidebarBtn.addEventListener('click', () => {
    sidebarMore.classList.toggle('active');
  });
}

// Form input validation for enabling Send button
const formInputs = document.querySelectorAll('[data-form-input]');
const sendBtn = document.querySelector('[data-form-btn]');

function checkFormFilled() {
  let allFilled = true;
  formInputs.forEach(input => {
    if (!input.value.trim()) {
      allFilled = false;
    }
  });
  sendBtn.disabled = !allFilled;
}


formInputs.forEach(input => {
  input.addEventListener('input', checkFormFilled);
  checkFormFilled(); // Run after inputs are selected
  
  

});

